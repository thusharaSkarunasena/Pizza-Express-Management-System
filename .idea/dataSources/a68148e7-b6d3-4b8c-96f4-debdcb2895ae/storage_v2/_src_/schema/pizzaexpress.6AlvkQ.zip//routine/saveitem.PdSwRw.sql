create procedure saveItem(IN itemCode_vbl varchar(30), IN name_vbl varchar(30), IN description_vbl varchar(150),
                          IN size_vbl     varchar(30), IN price_vbl double(10, 2), IN other_datail_vbl varchar(150))
  BEGIN 
  insert into item values (itemCode_vbl, name_vbl, description_vbl, size_vbl, price_vbl, other_datail_vbl );
END;

