create procedure saveOrder(IN orderID_vbl     varchar(30), IN orderDate_vbl varchar(30), IN customerID_vbl varchar(30),
                           IN totalAmount_vbl double(10, 2), IN discount_vbl double(10, 2),
                           IN netAmount_vbl   double(10, 2), IN orderTIme_vbl varchar(30),
                           IN employeeID_vbl  varchar(30), IN status_vbl varchar(30))
  BEGIN
  insert into orders values (orderID_vbl, orderDate_vbl, customerID_vbl, totalAmount_vbl, discount_vbl, netAmount_vbl, orderTIme_vbl, employeeID_vbl, null, null, null, null, null, null, status_vbl);
END;

