create procedure searchOrder(IN searchText varchar(30))
  BEGIN
  DECLARE newSearchText VARCHAR(30);
  set newSearchText=concat("%",searchText,"%");
  select * from orders where orderDate like newSearchText or customerID like newSearchText or status like newSearchText;
END;

