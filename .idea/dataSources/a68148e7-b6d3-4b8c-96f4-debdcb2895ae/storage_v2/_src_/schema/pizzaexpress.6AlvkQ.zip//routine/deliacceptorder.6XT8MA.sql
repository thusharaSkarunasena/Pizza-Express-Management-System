create procedure deliAcceptOrder(IN orderID_vbl varchar(30), IN time_vbl time, IN deliID_vbl varchar(30),
                                 IN status_vbl  varchar(30))
  BEGIN
  update orders set empID3_T1=time_vbl, employeeID3=chefID_vbl, status=status_vbl where orderID=orderID_vbl;
END;

