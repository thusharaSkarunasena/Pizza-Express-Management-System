create procedure generateOrderID()
  BEGIN
  select orderID from orders order by 1 desc limit 1;
END;

