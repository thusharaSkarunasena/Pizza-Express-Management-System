create procedure adminSearchOrders(IN searchText varchar(60))
  BEGIN
  DECLARE newSearchText VARCHAR(30);
  set newSearchText=concat("%",searchText,"%");
  select orderID, orderDate, customerID, totalAmount, discount, netAmount, status, employeeID1, empID1_T1,  employeeID2, empID2_T1, empID2_T2, employeeID3, empID3_T1, empID3_T2 from orders where orderDate like newSearchText or customerID like newSearchText or status like newSearchText ;
END;

