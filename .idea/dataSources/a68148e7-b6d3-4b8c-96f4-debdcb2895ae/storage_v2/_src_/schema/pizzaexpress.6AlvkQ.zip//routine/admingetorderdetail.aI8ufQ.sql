create procedure adminGetOrderDetail(IN orderID_vbl varchar(30))
  BEGIN
  select item.itemCode, item.name, item.size, orderDetail.qty  from item, orders, orderDetail where orders.orderID=orderDetail.orderID and orderDetail.itemCode=item.itemCode and orderDetail.orderID=orderID_vbl;
END;

