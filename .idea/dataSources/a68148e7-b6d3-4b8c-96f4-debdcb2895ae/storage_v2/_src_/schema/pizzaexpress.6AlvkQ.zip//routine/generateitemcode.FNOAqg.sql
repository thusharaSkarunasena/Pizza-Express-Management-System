create procedure generateItemCode()
  BEGIN
  select itemCode from item order by 1 desc limit 1;
END;

