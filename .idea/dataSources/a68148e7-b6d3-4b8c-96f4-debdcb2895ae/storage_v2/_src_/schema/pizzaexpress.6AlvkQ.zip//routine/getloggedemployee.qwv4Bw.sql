create procedure getLoggedEmployee(IN username_vbl varchar(30), IN password_vbl varchar(30))
  BEGIN
  select * from employee where employeeID=(select userPass.employeeID from userPass where username=username_vbl and password=password_vbl);
END;

