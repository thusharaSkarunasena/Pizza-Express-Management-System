create procedure saveCustomer(IN customerID_vbl     varchar(30), IN name_vbl varchar(60), IN address_no_vbl varchar(30),
                              IN address_street_vbl varchar(30), IN address_village_vbl varchar(30),
                              IN address_city_vbl   varchar(30), IN nic_vbl varchar(30), IN tel_home_vbl varchar(10),
                              IN tel_mobile_vbl     varchar(10), IN email_vbl varchar(60))
  BEGIN
  insert into customer values (
    customerID_vbl,
    name_vbl,
    address_no_vbl,
    address_street_vbl,
    address_village_vbl,
    address_city_vbl,
    nic_vbl,
    tel_home_vbl,
    tel_mobile_vbl,
    email_vbl
  );
END;

