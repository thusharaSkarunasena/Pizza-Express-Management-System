create procedure getItem(IN itemCode_vbl varchar(30))
  BEGIN
  select * from item where itemCode=itemCode_vbl;
END;

