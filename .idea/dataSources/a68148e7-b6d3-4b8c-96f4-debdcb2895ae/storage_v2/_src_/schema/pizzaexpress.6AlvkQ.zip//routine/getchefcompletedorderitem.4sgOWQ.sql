create procedure getChefCompletedOrderItem(IN orderID_vbl varchar(30))
  BEGIN
  select orderDetail.itemCode, item.name, item.size, orderDetail.qty  from item, orderDetail where orderDetail.itemCode=item.itemCode and orderDetail.orderID=orderID_vbl;
END;

