create procedure updateItem(IN itemCode_vbl varchar(30), IN name_vbl varchar(30), IN description_vbl varchar(150),
                            IN size_vbl     varchar(30), IN price_vbl double(10, 2), IN other_datail_vbl varchar(150))
  BEGIN
  update item set 
    name=name_vbl,
    description=description_vbl,
    size=size_vbl,
    price=price_vbl,
    other_detail=other_datail_vbl
  where itemCode=itemCode_vbl;
END;

