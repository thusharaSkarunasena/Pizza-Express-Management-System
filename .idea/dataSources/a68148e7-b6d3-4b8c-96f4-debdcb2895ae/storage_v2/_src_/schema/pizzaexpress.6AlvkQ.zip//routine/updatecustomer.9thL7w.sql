create procedure updateCustomer(IN customerID_vbl      varchar(30), IN name_vbl varchar(60),
                                IN address_no_vbl      varchar(30), IN address_street_vbl varchar(30),
                                IN address_village_vbl varchar(30), IN address_city_vbl varchar(30),
                                IN nic_vbl             varchar(30), IN tel_home_vbl varchar(10),
                                IN tel_mobile_vbl      varchar(10), IN email_vbl varchar(60))
  BEGIN 
  update customer set 
    name=name_vbl,
    address_no=address_no_vbl,
    address_street=address_street_vbl,
    address_village=address_village_vbl,
    address_city=address_city_vbl,
    nic=nic_vbl,
    tel_home=tel_home_vbl,
    tel_mobile=tel_mobile_vbl,
    email=email_vbl
  where customerID=customerID_vbl;
END;

