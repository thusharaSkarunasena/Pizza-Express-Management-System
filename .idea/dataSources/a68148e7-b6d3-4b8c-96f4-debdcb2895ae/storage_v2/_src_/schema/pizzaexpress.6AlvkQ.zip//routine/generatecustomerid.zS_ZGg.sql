create procedure generateCustomerID()
  BEGIN
  select customerID from customer order by 1 desc limit 1;
END;

