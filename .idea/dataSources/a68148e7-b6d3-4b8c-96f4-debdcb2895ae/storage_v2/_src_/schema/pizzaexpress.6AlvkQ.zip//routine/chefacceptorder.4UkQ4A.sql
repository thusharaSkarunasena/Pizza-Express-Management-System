create procedure chefAcceptOrder(IN orderID_vbl varchar(30), IN time_vbl time, IN chefID_vbl varchar(30),
                                 IN status_vbl  varchar(30))
  BEGIN
  update orders set empID2_T1=time_vbl, employeeID2=chefID_vbl, status=status_vbl where orderID=orderID_vbl;
END;

