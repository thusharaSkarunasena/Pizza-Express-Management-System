create procedure getOrder(IN orderID_vbl varchar(30))
  BEGIN
  select * from orders where orderID=orderID_vbl;
END;

