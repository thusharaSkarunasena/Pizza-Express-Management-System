create procedure saveOrderDetail(IN orderID_vbl     varchar(30), IN itemCode_vbl varchar(30), IN qty_vbl int,
                                 IN priceForQty_vbl double(10, 2))
  BEGIN 
  insert into orderDetail values(orderID_vbl, itemCode_vbl, qty_vbl, priceForQty_vbl);
END;

