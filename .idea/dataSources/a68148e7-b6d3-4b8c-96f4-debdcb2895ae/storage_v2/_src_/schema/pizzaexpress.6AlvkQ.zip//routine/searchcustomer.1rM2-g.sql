create procedure searchCustomer(IN searchText varchar(30))
  BEGIN 
  DECLARE newSearchText VARCHAR(30);
  set newSearchText=concat("%",searchText,"%");
  select * from customer where customerID like newSearchText or name like newSearchText or nic like newSearchText;
END;

