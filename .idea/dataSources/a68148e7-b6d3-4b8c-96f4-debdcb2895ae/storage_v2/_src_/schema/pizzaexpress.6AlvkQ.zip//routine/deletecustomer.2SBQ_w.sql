create procedure deleteCustomer(IN customerID_vbl varchar(30))
  BEGIN
  delete from customer where customerID=customerID_vbl;
END;

