create procedure getAllQueuedOrders()
  BEGIN
  select * from orders where status="queue";
END;

