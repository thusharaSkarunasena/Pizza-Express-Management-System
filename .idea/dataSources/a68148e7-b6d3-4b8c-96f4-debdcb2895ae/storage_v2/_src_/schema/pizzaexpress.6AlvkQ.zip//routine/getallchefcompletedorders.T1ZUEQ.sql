create procedure getAllChefCompletedOrders(IN chefID_vbl varchar(30))
  BEGIN
  select orderID, orderDate, empID2_T1, empID2_T2, status from orders where employeeID2=chefID_vbl;
END;

