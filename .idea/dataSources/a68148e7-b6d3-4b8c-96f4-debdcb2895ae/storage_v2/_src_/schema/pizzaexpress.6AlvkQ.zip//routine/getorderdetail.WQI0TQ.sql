create procedure getOrderDetail(IN orderID_vbl varchar(30))
  BEGIN
  select * from orderDetail where orderID=orderID_vbl;
END;

