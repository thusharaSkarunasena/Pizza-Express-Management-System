create procedure searchItem(IN searchText varchar(30))
  BEGIN
  DECLARE newSearchText VARCHAR(30);
  set newSearchText=concat("%",searchText,"%");
  select * from item where itemCode like newSearchText or name like newSearchText or size like newSearchText;
END;

