create procedure getAllOrders()
  BEGIN
  select * from orders;
END;

