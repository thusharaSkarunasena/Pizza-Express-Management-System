create procedure getCustomer(IN customerID_vbl varchar(30))
  BEGIN
  select * from customer where customerID=customerID_vbl;
END;

