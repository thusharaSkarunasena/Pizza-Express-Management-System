create procedure deleteOrder(IN orderID_vbl varchar(30))
  BEGIN
    delete from orders where orderID=orderID_vbl;
    delete from orderDetail where orderID=orderID_vbl;
END;

