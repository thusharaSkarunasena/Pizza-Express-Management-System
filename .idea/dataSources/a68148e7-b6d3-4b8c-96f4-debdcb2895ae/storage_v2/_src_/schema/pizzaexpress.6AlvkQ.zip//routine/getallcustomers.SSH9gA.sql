create procedure getAllCustomers()
  BEGIN
  select * from customer;
END;

