create procedure deleteItem(IN itemCode_vbl varchar(30))
  BEGIN
  delete from item where itemCode=itemCode_vbl;
END;

