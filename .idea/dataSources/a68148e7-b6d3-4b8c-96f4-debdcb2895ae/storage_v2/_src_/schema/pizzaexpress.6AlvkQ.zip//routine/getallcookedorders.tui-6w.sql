create procedure getAllCookedOrders()
  BEGIN
  select orders.orderID, orders.empID2_T2, customer.name, customer.address_no, customer.address_street, customer.address_village, customer.address_city, customer.tel_home, customer.tel_mobile from orders, customer where orders.customerID=customer.customerID and orders.status='Cooked';
END;

