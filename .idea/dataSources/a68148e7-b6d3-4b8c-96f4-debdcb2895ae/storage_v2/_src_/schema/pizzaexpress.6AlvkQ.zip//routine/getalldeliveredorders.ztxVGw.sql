create procedure getAllDeliveredOrders(IN deliID_vbl varchar(30))
  BEGIN
  select orders.orderID, orders.orderDate, orders.empID3_T1, orders.empID3_T2, customer.name, customer.address_no, customer.address_street, customer.address_village, customer.address_city, customer.tel_home, customer.tel_mobile, orders.status from orders, customer where orders.customerID=customer.customerID and orders.employeeID3=deliID_vbl;
END;

