create procedure getAllItems()
  BEGIN
  select * from item;
END;

